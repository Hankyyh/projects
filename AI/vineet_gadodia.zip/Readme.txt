Name:Vineet Gadodia
USC ID:3075-3595-01
email:gadodia@usc.edu

-----------------------------------------------------------------------------------------------
Problem 1a:

Query: basket(Sol).

Output:
Sol = [red,brown,green,blue,yellow,purple,orange] ? ;

Sol = [red,brown,yellow,blue,green,purple,orange] ? ;

Sol = [red,brown,green,orange,yellow,purple,blue] ? ;

Sol = [red,brown,yellow,orange,green,purple,blue] ? ;

(3 ms) no
| ?- 
------------------------------------------------------------------------------------------------

Problem 1b:

Query: balloon(Sol).

Output:

Sol = [blue,orange,red,green,yellow,brown,purple] ? ;

(2 ms) no
| ?- 
------------------------------------------------------------------------------------------------
